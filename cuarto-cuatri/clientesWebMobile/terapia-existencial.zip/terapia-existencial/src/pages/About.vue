<script>
export default {
 name: 'About',
}
</script>
<template>
<h1 class="text-3xl font-bold">Quienes somos</h1>
</template>