<script>
export default {
  name: 'Loader',
}
</script>

<template>
  <div class="">
    <i class="fa-solid fa-spinner fa-spin-pulse px-3"></i><span>Cargando...</span>
  </div>
</template>