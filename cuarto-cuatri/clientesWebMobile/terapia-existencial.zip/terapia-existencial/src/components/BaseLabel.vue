<script>
export default {
  name: 'BaseLabel',
}
</script>

<template>
  <label class="form-label">
    <slot />
  </label>
</template>