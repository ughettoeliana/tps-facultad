<script>
export default {
  name: 'BaseNavLi',
}
</script>

<template>
  <li class="d-inline-block mx-2 justify-content-end">
    <slot />
  </li>
</template>